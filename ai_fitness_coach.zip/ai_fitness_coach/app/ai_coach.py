"""
AI Personal Fitness Coach Expert Engine
Supports intelligent built-in expert knowledge responses + optional Groq / OpenAI / Gemini LLM integration.
"""

import httpx
import json

EXPERT_KNOWLEDGE_BASE = [
    {
        "keywords": ["knee", "knee pain", "joint pain", "hurt knee"],
        "reply": "When experiencing knee pain or joint strain, it is crucial to eliminate high-impact loads and jumping movements to protect the cartilage and joint capsule.",
        "warnings": [
            "Avoid high-impact jumping exercises (Jump Squats, Burpees, Jump Rope).",
            "Avoid deep heavy lunges or squatting past 90 degrees."
        ],
        "recommendations": [
            "Brisk Walking on flat surfaces",
            "Stationary Cycling (low resistance, high seat height)",
            "Swimming (low-impact full body resistance)",
            "Light Quad & Hamstring stretches",
            "Straight-Leg Raises to strengthen surrounding muscles"
        ]
    },
    {
        "keywords": ["back", "back pain", "lower back", "spine", "lumbar"],
        "reply": "Lower back pain often results from tight hip flexors, weak core stability, or poor posture. Focus on spine decompression and gentle core stabilization.",
        "warnings": [
            "Avoid heavy deadlifts, bent-over rows, or spinal flexion crunches.",
            "Avoid explosive twisting or high-impact running on hard asphalt."
        ],
        "recommendations": [
            "Bird-Dog exercise (core stability)",
            "Glute Bridges (posterior chain activation)",
            "Cat-Cow Stretches",
            "Gentle Walking",
            "Plank Holds with neutral spine alignment"
        ]
    },
    {
        "keywords": ["shoulder", "shoulder pain", "rotator cuff"],
        "reply": "Shoulder strain usually stems from rotator cuff impingement or weak scapular retractors. Give the overhead joints rest while building upper back support.",
        "warnings": [
            "Avoid overhead pressing and upright rows.",
            "Avoid deep dips or wide-grip bench press."
        ],
        "recommendations": [
            "Face Pulls with light resistance bands",
            "Scapular Push Ups",
            "Doorway Chest Stretches",
            "Prone Y-T-W arm raises for scapular control"
        ]
    },
    {
        "keywords": ["lose weight", "weight loss", "fat loss", "burn fat", "belly fat"],
        "reply": "Sustainable fat loss comes from creating a modest caloric deficit (300-500 kcal/day below TDEE) combined with high-protein intake and resistance training to preserve lean muscle.",
        "warnings": [
            "Avoid extreme crash diets below 1200 kcal.",
            "Don't rely solely on cardio—strength training keeps your metabolism high!"
        ],
        "recommendations": [
            "Maintain 1.6g to 2.2g of protein per kg of body weight",
            "Drink 3+ Liters of water daily to support hydration and satiety",
            "Incorporate 3x weekly Strength/HIIT sessions + 10k daily steps",
            "Prioritize 7-8 hours of quality sleep for recovery"
        ]
    },
    {
        "keywords": ["muscle", "gain muscle", "hypertrophy", "build muscle", "bulk"],
        "reply": "Muscle growth requires progressive overload in training, adequate mechanical tension, and a slight caloric surplus (250-400 kcal above maintenance) with ample protein.",
        "warnings": [
            "Avoid training the same muscle group hard 2 days in a row.",
            "Don't skip rest days—muscles grow during rest, not during the workout!"
        ],
        "recommendations": [
            "Aim for 3-4 sets of 8-12 reps per exercise",
            "Consume 1.8g - 2.2g of protein per kg body weight daily",
            "Log your weights and try to increase reps or load gradually each week",
            "Eat nutrient-dense whole foods and healthy complex carbs around workouts"
        ]
    },
    {
        "keywords": ["warmup", "warm up", "stretch", "stretching"],
        "reply": "A proper warm-up raises body temperature, lubricates joints with synovial fluid, and prepares your nervous system for performance.",
        "warnings": [
            "Avoid static stretching before heavy workouts (it temporarily lowers power output)."
        ],
        "recommendations": [
            "Dynamic mobility: Arm Circles, Hip Swings, Leg Swings, Torso Twists",
            "5 minutes of light cardio (Brisk Walk or Light Jump Rope)",
            "Save static stretches (holding 30s) for post-workout cool-down"
        ]
    }
]

def generate_ai_response(user_message: str, provider: str = "built-in", api_key: str = None) -> dict:
    msg_lower = user_message.lower()

    # If external provider is requested and key exists
    if provider in ["groq", "openai", "gemini"] and api_key:
        try:
            return call_external_llm(user_message, provider, api_key)
        except Exception as e:
            # Fall back to built-in rule engine gracefully
            pass

    # Built-in Expert Rule & Knowledge Base Search
    for kb in EXPERT_KNOWLEDGE_BASE:
        for kw in kb["keywords"]:
            if kw in msg_lower:
                return {
                    "reply": kb["reply"],
                    "warnings": kb.get("warnings", []),
                    "recommendations": kb.get("recommendations", [])
                }

    # General Intelligent Fitness Advice Fallback
    return {
        "reply": f"Thanks for asking! Regarding '{user_message}': To optimize your fitness journey, ensure you maintain consistency with a structured workout split, stay hydrated, and balance your macronutrient intake based on your body goal.",
        "warnings": [
            "Always listen to your body and stop any movement that causes sharp pain.",
            "Ensure proper exercise form before increasing intensity or weight."
        ],
        "recommendations": [
            "Follow your daily automated Workout Routine in the planner tab.",
            "Log your workouts and daily water intake in the dashboard.",
            "Consult a medical professional if pain or physical discomfort persists."
        ]
    }

def call_external_llm(prompt: str, provider: str, api_key: str) -> dict:
    system_prompt = (
        "You are an expert AI Personal Trainer and Sports Nutritionist. "
        "Analyze the user query and output a concise response highlighting key advice, "
        "exercise warnings, and recommended activities."
    )

    if provider == "groq":
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {
            "model": "llama-3.1-70b-versatile",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7
        }
        with httpx.Client(timeout=10.0) as client:
            resp = client.post(url, headers=headers, json=payload)
            if resp.status_code == 200:
                content = resp.json()["choices"][0]["message"]["content"]
                return parse_llm_text(content)

    elif provider == "openai":
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {
            "model": "gpt-4o-mini",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ]
        }
        with httpx.Client(timeout=10.0) as client:
            resp = client.post(url, headers=headers, json=payload)
            if resp.status_code == 200:
                content = resp.json()["choices"][0]["message"]["content"]
                return parse_llm_text(content)

    raise ValueError("LLM request failed")

def parse_llm_text(text: str) -> dict:
    # Helper to parse text response into reply, recommendations, warnings
    lines = text.split("\n")
    recs = []
    warns = []
    clean_lines = []

    for line in lines:
        l = line.strip()
        if l.startswith("✓") or l.startswith("-") or l.startswith("*"):
            recs.append(l.lstrip("✓-* ").strip())
        elif "avoid" in l.lower() or "warning" in l.lower():
            warns.append(l)
        else:
            if l:
                clean_lines.append(l)

    return {
        "reply": "\n".join(clean_lines) if clean_lines else text,
        "recommendations": recs if recs else ["Consistency", "Hydration", "Proper Form"],
        "warnings": warns if warns else ["Avoid overexertion."]
    }
