from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class UserProfile(Base):
    __tablename__ = "user_profiles"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=True)
    email = Column(String, unique=True, index=True, nullable=True)
    password_hash = Column(String, nullable=True)
    salt = Column(String, nullable=True)

    name = Column(String, default="Fitness Enthusiast")
    age = Column(Integer, default=25)
    gender = Column(String, default="Male")
    height = Column(Float, default=175.0)  # cm
    weight = Column(Float, default=75.0)   # kg
    target_weight = Column(Float, default=70.0) # kg
    fitness_goal = Column(String, default="Weight Loss") # Weight Loss, Muscle Gain, Maintain Weight
    fitness_level = Column(String, default="Intermediate") # Beginner, Intermediate, Advanced
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    weight_logs = relationship("WeightLog", back_populates="user", cascade="all, delete-orphan")
    activity_logs = relationship("DailyActivity", back_populates="user", cascade="all, delete-orphan")

class WeightLog(Base):
    __tablename__ = "weight_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("user_profiles.id"))
    weight = Column(Float, nullable=False)
    notes = Column(String, nullable=True)
    logged_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("UserProfile", back_populates="weight_logs")

class WorkoutRoutine(Base):
    __tablename__ = "workout_routines"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("user_profiles.id"), nullable=True)
    day = Column(String, nullable=False) # Monday, Tuesday, etc.
    title = Column(String, nullable=False)
    is_rest_day = Column(Boolean, default=False)
    exercises_json = Column(Text, nullable=False) # JSON array of exercises
    created_at = Column(DateTime, default=datetime.utcnow)

class DailyActivity(Base):
    __tablename__ = "daily_activities"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("user_profiles.id"))
    date = Column(String, nullable=False) # YYYY-MM-DD
    water_ml = Column(Integer, default=0) # ml water consumed (goal: 3000ml)
    sleep_hours = Column(Float, default=0.0) # hours slept
    calories_burned = Column(Integer, default=0) # kcal
    protein_g = Column(Integer, default=0) # grams protein

    user = relationship("UserProfile", back_populates="activity_logs")

class ChatHistory(Base):
    __tablename__ = "chat_history"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("user_profiles.id"), nullable=True)
    sender = Column(String, nullable=False) # 'user' or 'ai'
    message = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
