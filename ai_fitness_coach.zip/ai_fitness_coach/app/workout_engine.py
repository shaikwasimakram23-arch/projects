"""
Intelligent Automated Workout Routine Generator
Creates tailored 7-day fitness schedules based on user goal, fitness level, and body metrics.
"""

def generate_weekly_workout_plan(fitness_goal: str = "Weight Loss", fitness_level: str = "Intermediate") -> list:
    goal = fitness_goal.lower()
    level = fitness_level.lower()

    # Rep/Set multipliers based on level
    if level == "beginner":
        sets_mult = 3
        pushups_reps = "10"
        squats_reps = "12"
        plank_dur = "30 sec"
        run_dur = "15 mins"
        pullups_reps = "3-5"
        lunges_reps = "10 each side"
        jumprope_dur = "5 mins"
    elif level == "advanced":
        sets_mult = 4
        pushups_reps = "25"
        squats_reps = "30"
        plank_dur = "60 sec"
        run_dur = "30 mins"
        pullups_reps = "12-15"
        lunges_reps = "20 each side"
        jumprope_dur = "15 mins"
    else: # Intermediate
        sets_mult = 3
        pushups_reps = "15"
        squats_reps = "20"
        plank_dur = "45 sec"
        run_dur = "20 mins"
        pullups_reps = "8-10"
        lunges_reps = "15 each side"
        jumprope_dur = "10 mins"

    if "loss" in goal:
        # Cardio & High Rep Bodyweight Focus
        schedule = [
            {
                "day": "Monday",
                "title": "Upper Body & Cardio Burn",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Push Ups", "sets": sets_mult, "reps": pushups_reps, "duration": None, "muscle_group": "Chest & Triceps", "type": "bodyweight"},
                    {"name": "Squats", "sets": sets_mult, "reps": squats_reps, "duration": None, "muscle_group": "Quads & Glutes", "type": "bodyweight"},
                    {"name": "Plank Hold", "sets": sets_mult, "reps": None, "duration": plank_dur, "muscle_group": "Core", "type": "bodyweight"},
                    {"name": "Running / Jogging", "sets": 1, "reps": None, "duration": run_dur, "muscle_group": "Full Body Cardio", "type": "cardio"}
                ]
            },
            {
                "day": "Tuesday",
                "title": "Rest & Active Recovery",
                "is_rest_day": True,
                "exercises": []
            },
            {
                "day": "Wednesday",
                "title": "Pull & Lower Body Conditioning",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Pull Ups (or Inverted Rows)", "sets": sets_mult, "reps": pullups_reps, "duration": None, "muscle_group": "Back & Biceps", "type": "bodyweight"},
                    {"name": "Walking Lunges", "sets": sets_mult, "reps": lunges_reps, "duration": None, "muscle_group": "Legs & Core", "type": "bodyweight"},
                    {"name": "Jump Rope HIIT", "sets": 3, "reps": None, "duration": jumprope_dur, "muscle_group": "Calves & Cardio", "type": "cardio"},
                    {"name": "Mountain Climbers", "sets": sets_mult, "reps": "30 sec", "duration": "30 sec", "muscle_group": "Core & Cardio", "type": "bodyweight"}
                ]
            },
            {
                "day": "Thursday",
                "title": "Active Mobility & Stretching",
                "is_rest_day": True,
                "exercises": []
            },
            {
                "day": "Friday",
                "title": "Full Body HIIT & Core Strength",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Burpees", "sets": sets_mult, "reps": "12", "duration": None, "muscle_group": "Full Body", "type": "bodyweight"},
                    {"name": "Dips (Chair or Bars)", "sets": sets_mult, "reps": "12", "duration": None, "muscle_group": "Triceps & Chest", "type": "bodyweight"},
                    {"name": "Bicycle Crunches", "sets": sets_mult, "reps": "20", "duration": None, "muscle_group": "Abs & Obliques", "type": "bodyweight"},
                    {"name": "Brisk Cycling / Stationary Bike", "sets": 1, "reps": None, "duration": "25 mins", "muscle_group": "Legs & Cardio", "type": "cardio"}
                ]
            },
            {
                "day": "Saturday",
                "title": "Endurance & Steady State Cardio",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Outdoor Run or Swimming", "sets": 1, "reps": None, "duration": "30 mins", "muscle_group": "Full Body Cardio", "type": "cardio"},
                    {"name": "Full Body Foam Rolling / Yoga", "sets": 1, "reps": None, "duration": "15 mins", "muscle_group": "Flexibility", "type": "mobility"}
                ]
            },
            {
                "day": "Sunday",
                "title": "Rest Day",
                "is_rest_day": True,
                "exercises": []
            }
        ]
    elif "gain" in goal or "muscle" in goal:
        # Hypertrophy & Resistance Focus
        schedule = [
            {
                "day": "Monday",
                "title": "Push Day (Chest, Shoulders, Triceps)",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Diamond / Decline Push Ups", "sets": 4, "reps": pushups_reps, "duration": None, "muscle_group": "Chest & Triceps", "type": "bodyweight"},
                    {"name": "Pike Push Ups", "sets": 4, "reps": "10-12", "duration": None, "muscle_group": "Shoulders", "type": "bodyweight"},
                    {"name": "Chair Dips", "sets": 4, "reps": "15", "duration": None, "muscle_group": "Triceps", "type": "bodyweight"},
                    {"name": "Bodyweight Squats", "sets": 4, "reps": squats_reps, "duration": None, "muscle_group": "Quads", "type": "bodyweight"}
                ]
            },
            {
                "day": "Tuesday",
                "title": "Pull Day (Back, Biceps, Rear Delts)",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Wide Grip Pull Ups", "sets": 4, "reps": pullups_reps, "duration": None, "muscle_group": "Lats & Upper Back", "type": "bodyweight"},
                    {"name": "Chin Ups", "sets": 3, "reps": "8-10", "duration": None, "muscle_group": "Biceps", "type": "bodyweight"},
                    {"name": "Superman Back Extensions", "sets": 3, "reps": "15", "duration": None, "muscle_group": "Lower Back", "type": "bodyweight"}
                ]
            },
            {
                "day": "Wednesday",
                "title": "Rest & Muscle Growth Recovery",
                "is_rest_day": True,
                "exercises": []
            },
            {
                "day": "Thursday",
                "title": "Legs & Core Overload",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Bulgarian Split Squats", "sets": 4, "reps": "12 each leg", "duration": None, "muscle_group": "Quads & Glutes", "type": "bodyweight"},
                    {"name": "Single Leg Glute Bridges", "sets": 3, "reps": "15 each leg", "duration": None, "muscle_group": "Hamstrings & Glutes", "type": "bodyweight"},
                    {"name": "Calf Raises", "sets": 4, "reps": "25", "duration": None, "muscle_group": "Calves", "type": "bodyweight"},
                    {"name": "Plank with Shoulder Taps", "sets": 3, "reps": None, "duration": plank_dur, "muscle_group": "Core", "type": "bodyweight"}
                ]
            },
            {
                "day": "Friday",
                "title": "Full Body Hypertrophy",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Explosive Push Ups", "sets": 3, "reps": "12", "duration": None, "muscle_group": "Chest", "type": "bodyweight"},
                    {"name": "Inverted Rows", "sets": 4, "reps": "12", "duration": None, "muscle_group": "Upper Back", "type": "bodyweight"},
                    {"name": "Jump Squats", "sets": 3, "reps": "15", "duration": None, "muscle_group": "Explosive Legs", "type": "bodyweight"}
                ]
            },
            {
                "day": "Saturday",
                "title": "Core & Cardio Mobility",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Hanging Leg Raises / Knee Raises", "sets": 4, "reps": "12", "duration": None, "muscle_group": "Abs", "type": "bodyweight"},
                    {"name": "Light Jogging", "sets": 1, "reps": None, "duration": "15 mins", "muscle_group": "Cardio", "type": "cardio"}
                ]
            },
            {
                "day": "Sunday",
                "title": "Rest Day",
                "is_rest_day": True,
                "exercises": []
            }
        ]
    else: # Maintain Weight
        schedule = [
            {
                "day": "Monday",
                "title": "Balanced Push & Core",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Push Ups", "sets": 3, "reps": pushups_reps, "duration": None, "muscle_group": "Chest", "type": "bodyweight"},
                    {"name": "Squats", "sets": 3, "reps": squats_reps, "duration": None, "muscle_group": "Legs", "type": "bodyweight"},
                    {"name": "Plank", "sets": 3, "reps": None, "duration": plank_dur, "muscle_group": "Core", "type": "bodyweight"},
                    {"name": "Running", "sets": 1, "reps": None, "duration": run_dur, "muscle_group": "Cardio", "type": "cardio"}
                ]
            },
            {
                "day": "Tuesday",
                "title": "Rest Day",
                "is_rest_day": True,
                "exercises": []
            },
            {
                "day": "Wednesday",
                "title": "Balanced Pull & Legs",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Pull Ups", "sets": 3, "reps": pullups_reps, "duration": None, "muscle_group": "Back", "type": "bodyweight"},
                    {"name": "Lunges", "sets": 3, "reps": lunges_reps, "duration": None, "muscle_group": "Legs", "type": "bodyweight"},
                    {"name": "Jump Rope", "sets": 3, "reps": None, "duration": jumprope_dur, "muscle_group": "Cardio", "type": "cardio"}
                ]
            },
            {
                "day": "Thursday",
                "title": "Active Mobility & Walk",
                "is_rest_day": True,
                "exercises": []
            },
            {
                "day": "Friday",
                "title": "Full Body Conditioning",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Dips", "sets": 3, "reps": "12", "duration": None, "muscle_group": "Arms", "type": "bodyweight"},
                    {"name": "Bodyweight Squats", "sets": 3, "reps": "20", "duration": None, "muscle_group": "Legs", "type": "bodyweight"},
                    {"name": "Plank", "sets": 3, "reps": None, "duration": "45 sec", "muscle_group": "Core", "type": "bodyweight"}
                ]
            },
            {
                "day": "Saturday",
                "title": "Weekend Refresh Cardio",
                "is_rest_day": False,
                "exercises": [
                    {"name": "Cycling / Swimming", "sets": 1, "reps": None, "duration": "30 mins", "muscle_group": "Full Body", "type": "cardio"}
                ]
            },
            {
                "day": "Sunday",
                "title": "Rest Day",
                "is_rest_day": True,
                "exercises": []
            }
        ]

    return schedule
