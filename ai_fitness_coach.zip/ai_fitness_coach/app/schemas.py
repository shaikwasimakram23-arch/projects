from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime

class UserRegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: str = Field(..., min_length=5, max_length=100)
    password: str = Field(..., min_length=4, max_length=100)
    name: str = "Fitness Enthusiast"
    age: int = Field(default=25, ge=10, le=120)
    gender: str = "Male"
    height: float = Field(default=175.0, gt=50, lt=250)
    weight: float = Field(default=75.0, gt=20, lt=300)
    fitness_goal: str = "Weight Loss" # Weight Loss, Muscle Gain, Maintain Weight
    fitness_level: str = "Intermediate" # Beginner, Intermediate, Advanced

class UserLoginRequest(BaseModel):
    username_or_email: str
    password: str

class AuthTokenResponse(BaseModel):
    token: str
    username: str
    name: str
    user_id: int

class UserProfileBase(BaseModel):
    name: str = "Fitness Enthusiast"
    username: Optional[str] = None
    email: Optional[str] = None
    age: int = Field(default=25, ge=10, le=120)
    gender: str = "Male"
    height: float = Field(default=175.0, gt=50, lt=250)
    weight: float = Field(default=75.0, gt=20, lt=300)
    target_weight: float = Field(default=70.0, gt=20, lt=300)
    fitness_goal: str = "Weight Loss"
    fitness_level: str = "Intermediate"

class UserProfileCreate(UserProfileBase):
    pass

class UserProfileResponse(UserProfileBase):
    id: int
    bmi: float
    bmi_category: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class WeightLogCreate(BaseModel):
    weight: float = Field(..., gt=20, lt=300)
    notes: Optional[str] = None
    date: Optional[str] = None

class WeightLogResponse(BaseModel):
    id: int
    user_id: int
    weight: float
    notes: Optional[str]
    logged_at: datetime

    class Config:
        from_attributes = True

class ExerciseItem(BaseModel):
    name: str
    sets: Optional[int] = None
    reps: Optional[str] = None
    duration: Optional[str] = None
    muscle_group: str
    type: str

class DayWorkout(BaseModel):
    day: str
    title: str
    is_rest_day: bool
    exercises: List[ExerciseItem]

class CalorieCalcRequest(BaseModel):
    activity: str
    duration_minutes: int = Field(..., gt=0, le=720)
    user_weight_kg: Optional[float] = None

class CalorieCalcResponse(BaseModel):
    activity: str
    duration_minutes: int
    user_weight_kg: float
    calories_burned: float
    met_value: float

class ChatRequest(BaseModel):
    message: str
    api_key: Optional[str] = None
    provider: Optional[str] = "built-in"

class ChatResponse(BaseModel):
    reply: str
    recommendations: Optional[List[str]] = None
    warnings: Optional[List[str]] = None
