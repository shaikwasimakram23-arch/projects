from fastapi import APIRouter, Depends
from app.schemas import ChatRequest, ChatResponse
from app.ai_coach import generate_ai_response
from app.auth import get_current_user
from app.models import UserProfile

router = APIRouter(prefix="/api/chat", tags=["AI Trainer Chat"])

@router.post("/", response_model=ChatResponse)
def chat_with_trainer(req: ChatRequest, current_user: UserProfile = Depends(get_current_user)):
    result = generate_ai_response(
        user_message=req.message,
        provider=req.provider or "built-in",
        api_key=req.api_key
    )
    return ChatResponse(
        reply=result["reply"],
        recommendations=result.get("recommendations"),
        warnings=result.get("warnings")
    )
