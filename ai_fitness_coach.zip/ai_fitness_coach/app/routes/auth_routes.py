from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import UserProfile
from app.schemas import UserRegisterRequest, AuthTokenResponse, UserProfileResponse
from app.auth import get_password_hash, verify_password, create_access_token, ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter(prefix="/api/auth", tags=["Auth"])

@router.post("/register", response_model=AuthTokenResponse)
def register(data: UserRegisterRequest, db: Session = Depends(get_db)):
    # Check if user exists
    user_exists = db.query(UserProfile).filter(
        (UserProfile.username == data.username) | (UserProfile.email == data.email)
    ).first()
    
    if user_exists:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email already registered"
        )
        
    hashed_password = get_password_hash(data.password)
    
    new_user = UserProfile(
        username=data.username,
        email=data.email,
        password_hash=hashed_password,
        name=data.name,
        age=data.age,
        gender=data.gender,
        height=data.height,
        weight=data.weight,
        fitness_goal=data.fitness_goal,
        fitness_level=data.fitness_level
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": new_user.username}, expires_delta=access_token_expires
    )
    
    return AuthTokenResponse(
        token=access_token,
        username=new_user.username,
        name=new_user.name,
        user_id=new_user.id
    )

@router.post("/login", response_model=AuthTokenResponse)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(UserProfile).filter(
        (UserProfile.username == form_data.username) | (UserProfile.email == form_data.username)
    ).first()
    
    if not user or not verify_password(form_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    
    return AuthTokenResponse(
        token=access_token,
        username=user.username,
        name=user.name,
        user_id=user.id
    )
