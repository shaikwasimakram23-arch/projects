from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import UserProfile, WeightLog
from app.schemas import WeightLogCreate, WeightLogResponse
from typing import List
from app.auth import get_current_user

router = APIRouter(prefix="/api/tracker", tags=["Progress Tracker"])

@router.get("/weight-logs", response_model=List[WeightLogResponse])
def get_weight_logs(db: Session = Depends(get_db), current_user: UserProfile = Depends(get_current_user)):
    logs = db.query(WeightLog).filter(WeightLog.user_id == current_user.id).order_by(WeightLog.logged_at.asc()).all()
    return logs

@router.post("/weight-logs", response_model=WeightLogResponse)
def add_weight_log(log_data: WeightLogCreate, db: Session = Depends(get_db), current_user: UserProfile = Depends(get_current_user)):
    # Update profile current weight to latest logged weight
    current_user.weight = log_data.weight
    
    new_log = WeightLog(
        user_id=current_user.id,
        weight=log_data.weight,
        notes=log_data.notes or "Manual log"
    )
    db.add(new_log)
    db.commit()
    db.refresh(new_log)
    return new_log

@router.delete("/weight-logs/{log_id}")
def delete_weight_log(log_id: int, db: Session = Depends(get_db), current_user: UserProfile = Depends(get_current_user)):
    log = db.query(WeightLog).filter(WeightLog.id == log_id, WeightLog.user_id == current_user.id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Log entry not found")
    db.delete(log)
    db.commit()
    return {"message": "Log deleted successfully"}
