from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import UserProfile, WeightLog
from app.schemas import UserProfileCreate, UserProfileResponse
from datetime import datetime
from app.auth import get_current_user

router = APIRouter(prefix="/api/profile", tags=["Profile"])

def calculate_bmi_info(height_cm: float, weight_kg: float) -> tuple:
    if height_cm <= 0:
        return 0.0, "Unknown"
    height_m = height_cm / 100.0
    bmi = round(weight_kg / (height_m * height_m), 1)
    
    if bmi < 18.5:
        category = "Underweight"
    elif 18.5 <= bmi <= 24.9:
        category = "Normal Weight"
    elif 25.0 <= bmi <= 29.9:
        category = "Overweight"
    else:
        category = "Obese"
        
    return bmi, category

@router.get("/", response_model=UserProfileResponse)
def get_profile(current_user: UserProfile = Depends(get_current_user)):
    profile = current_user

    bmi, category = calculate_bmi_info(profile.height, profile.weight)
    
    res = UserProfileResponse(
        id=profile.id,
        name=profile.name,
        age=profile.age,
        gender=profile.gender,
        height=profile.height,
        weight=profile.weight,
        target_weight=profile.target_weight,
        fitness_goal=profile.fitness_goal,
        fitness_level=profile.fitness_level,
        bmi=bmi,
        bmi_category=category,
        created_at=profile.created_at,
        updated_at=profile.updated_at
    )
    return res

@router.post("/", response_model=UserProfileResponse)
def update_profile(data: UserProfileCreate, db: Session = Depends(get_db), current_user: UserProfile = Depends(get_current_user)):
    profile = current_user
    
    profile.name = data.name
    profile.age = data.age
    profile.gender = data.gender
    profile.height = data.height
    old_weight = profile.weight
    profile.weight = data.weight
    profile.target_weight = data.target_weight
    profile.fitness_goal = data.fitness_goal
    profile.fitness_level = data.fitness_level
    profile.updated_at = datetime.utcnow()

    # Log weight change if updated
    if old_weight != data.weight or not db.query(WeightLog).filter_by(user_id=profile.id).first():
        log = WeightLog(user_id=profile.id, weight=data.weight, notes="Profile update")
        db.add(log)

    db.commit()
    db.refresh(profile)

    bmi, category = calculate_bmi_info(profile.height, profile.weight)

    return UserProfileResponse(
        id=profile.id,
        name=profile.name,
        age=profile.age,
        gender=profile.gender,
        height=profile.height,
        weight=profile.weight,
        target_weight=profile.target_weight,
        fitness_goal=profile.fitness_goal,
        fitness_level=profile.fitness_level,
        bmi=bmi,
        bmi_category=category,
        created_at=profile.created_at,
        updated_at=profile.updated_at
    )
