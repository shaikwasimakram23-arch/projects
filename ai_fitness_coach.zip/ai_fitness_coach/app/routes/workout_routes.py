from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import UserProfile
from app.workout_engine import generate_weekly_workout_plan
from app.auth import get_current_user

router = APIRouter(prefix="/api/workout", tags=["Workout Planner"])

@router.get("/generate")
def get_workout_plan(fitness_goal: str = None, fitness_level: str = None, current_user: UserProfile = Depends(get_current_user)):
    profile = current_user
    
    goal = fitness_goal if fitness_goal else (profile.fitness_goal if profile else "Weight Loss")
    level = fitness_level if fitness_level else (profile.fitness_level if profile else "Intermediate")
    
    weekly_plan = generate_weekly_workout_plan(fitness_goal=goal, fitness_level=level)
    return {
        "fitness_goal": goal,
        "fitness_level": level,
        "weekly_schedule": weekly_plan
    }
