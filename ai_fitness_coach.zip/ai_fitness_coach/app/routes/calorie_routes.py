from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import UserProfile
from app.schemas import CalorieCalcRequest, CalorieCalcResponse
from app.calories_engine import calculate_calories, get_supported_activities
from app.auth import get_current_user

router = APIRouter(prefix="/api/calories", tags=["Calories Burned"])

@router.get("/activities")
def list_activities():
    return {"activities": get_supported_activities()}

@router.post("/calculate", response_model=CalorieCalcResponse)
def compute_calories(req: CalorieCalcRequest, current_user: UserProfile = Depends(get_current_user)):
    profile = current_user
    weight = req.user_weight_kg or (profile.weight if profile else 75.0)
    
    result = calculate_calories(
        activity=req.activity,
        duration_minutes=req.duration_minutes,
        weight_kg=weight
    )
    return result
