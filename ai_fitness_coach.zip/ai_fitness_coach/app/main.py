from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import os

from app.database import engine, Base
from app.routes import (
    profile_routes,
    workout_routes,
    tracker_routes,
    calorie_routes,
    chat_routes,
    auth_routes
)

# Initialize Database Tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI Personal Fitness Coach API",
    description="Intelligent Fitness Coach with automated workout planning, progress tracker, calorie calculator & AI trainer advice.",
    version="1.0.0"
)

# Enable CORS for easy local access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(profile_routes.router)
app.include_router(workout_routes.router)
app.include_router(tracker_routes.router)
app.include_router(calorie_routes.router)
app.include_router(chat_routes.router)
app.include_router(auth_routes.router)

# Static Files Path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "static")

if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
def read_root():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "AI Personal Fitness Coach API is running!"}
