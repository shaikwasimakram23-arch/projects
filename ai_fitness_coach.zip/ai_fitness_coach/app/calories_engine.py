"""
MET (Metabolic Equivalent of Task) Calorie Calculation Engine
Formula: Calories Burned = Duration (minutes) * (MET * 3.5 * Weight in kg) / 200
"""

ACTIVITIES_MET = {
    "Running (8 km/h)": 8.0,
    "Running (10 km/h)": 9.8,
    "Running (12 km/h)": 11.5,
    "Sprinting": 14.0,
    "Cycling (Moderate)": 6.8,
    "Cycling (Vigorous)": 10.0,
    "Swimming (Freestyle, Moderate)": 7.0,
    "Swimming (Vigorous)": 9.8,
    "Brisk Walking (5 km/h)": 3.8,
    "Light Walking (3 km/h)": 2.5,
    "Jump Rope (Moderate)": 10.0,
    "Jump Rope (Fast)": 12.3,
    "Push Ups / Calisthenics": 8.0,
    "Pull Ups": 8.0,
    "HIIT Workout": 9.0,
    "Weightlifting (Moderate)": 3.5,
    "Weightlifting (Heavy)": 6.0,
    "Yoga / Stretching": 2.5,
    "Pilates": 3.0,
    "Rowing Machine": 7.0,
    "Stair Climbing": 8.8,
    "Elliptical Trainer": 5.0,
    "Boxing / Heavy Bag": 7.8,
    "Basketball": 6.5,
    "Football / Soccer": 7.0,
    "Badminton": 4.5,
}

def calculate_calories(activity: str, duration_minutes: int, weight_kg: float) -> dict:
    # Match closest activity or default
    met = ACTIVITIES_MET.get(activity, 6.0)
    
    # Formula: (MET * 3.5 * weight_kg / 200) * duration_minutes
    calories = round((met * 3.5 * weight_kg / 200.0) * duration_minutes, 1)
    
    return {
        "activity": activity,
        "duration_minutes": duration_minutes,
        "user_weight_kg": weight_kg,
        "calories_burned": calories,
        "met_value": met
    }

def get_supported_activities() -> list:
    return list(ACTIVITIES_MET.keys())
