// Calorie Burn Calculator Handler
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('calorieCalcForm');
  
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const activity = document.getElementById('calcActivitySelect').value;
      const duration = parseInt(document.getElementById('calcDurationInput').value);

      try {
        const res = await window.apiFetch('/api/calories/calculate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ activity, duration_minutes: duration })
        });

        if (res.ok) {
          const data = await res.json();
          renderCalorieResult(data);
        }
      } catch (err) {
        console.error('Error calculating calories:', err);
      }
    });
  }

  loadActivitiesList();
});

async function loadActivitiesList() {
  try {
    const res = await window.apiFetch('/api/calories/activities');
    if (res.ok) {
      const data = await res.json();
      const select = document.getElementById('calcActivitySelect');
      if (select && data.activities) {
        select.innerHTML = '';
        data.activities.forEach(act => {
          const opt = document.createElement('option');
          opt.value = act;
          opt.innerText = act;
          if (act.includes("Running (8 km/h)")) opt.selected = true;
          select.appendChild(opt);
        });
      }
    }
  } catch (err) {
    console.error('Error loading activities:', err);
  }
}

function renderCalorieResult(data) {
  const calVal = document.getElementById('calcOutputCalories');
  const subtitle = document.getElementById('calcOutputSubtitle');
  const metBadge = document.getElementById('calcMetBadge');

  if (calVal) calVal.innerText = `${Math.round(data.calories_burned)} kcal`;
  if (subtitle) subtitle.innerText = `${data.activity} for ${data.duration_minutes} minutes`;
  if (metBadge) metBadge.innerText = `Calculated using MET Value: ${data.met_value} • Body Weight: ${data.user_weight_kg} kg`;
}
