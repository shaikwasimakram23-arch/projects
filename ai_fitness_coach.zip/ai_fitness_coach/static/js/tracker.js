// Progress Tracker - Weight Chart & History Logs
let weightChartInstance = null;

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('weightLogForm');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const weightVal = parseFloat(document.getElementById('logWeightInput').value);
      const notesVal = document.getElementById('logNotesInput').value;

      if (!weightVal) return;

      try {
        const res = await window.apiFetch('/api/tracker/weight-logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ weight: weightVal, notes: notesVal })
        });

        if (res.ok) {
          document.getElementById('logWeightInput').value = '';
          document.getElementById('logNotesInput').value = '';
          fetchWeightLogs();
          if (window.loadGlobalProfile) window.loadGlobalProfile();
        }
      } catch (err) {
        console.error('Error adding weight log:', err);
      }
    });
  }
  if (window.getAuthToken && window.getAuthToken()) {
    fetchWeightLogs();
  }
});

async function fetchWeightLogs() {
  try {
    const res = await window.apiFetch('/api/tracker/weight-logs');
    if (res.ok) {
      const logs = await res.json();
      renderChart(logs);
      renderTable(logs);
    }
  } catch (err) {
    console.error('Error fetching weight logs:', err);
  }
}

function renderChart(logs) {
  const canvas = document.getElementById('weightChart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');

  const labels = logs.map(l => new Date(l.logged_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }));
  const dataPoints = logs.map(l => l.weight);

  if (weightChartInstance) {
    weightChartInstance.destroy();
  }

  // Create gradient background
  const gradient = ctx.createLinearGradient(0, 0, 0, 300);
  gradient.addColorStop(0, 'rgba(59, 130, 246, 0.4)');
  gradient.addColorStop(1, 'rgba(59, 130, 246, 0.0)');

  weightChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Weight (kg)',
        data: dataPoints,
        borderColor: '#3b82f6',
        borderWidth: 3,
        pointBackgroundColor: '#10b981',
        pointBorderColor: '#fff',
        pointRadius: 6,
        pointHoverRadius: 8,
        tension: 0.35,
        fill: true,
        backgroundColor: gradient
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleColor: '#f8fafc',
          bodyColor: '#60a5fa',
          borderColor: 'rgba(255, 255, 255, 0.1)',
          borderWidth: 1,
          padding: 12,
          displayColors: false,
          callbacks: {
            label: (ctx) => `Weight: ${ctx.raw} kg`
          }
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: { color: '#94a3b8' }
        },
        y: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: {
            color: '#94a3b8',
            callback: (val) => `${val} kg`
          }
        }
      }
    }
  });
}

function renderTable(logs) {
  const tbody = document.getElementById('weightHistoryTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  // Show newest logs first in table
  const reversed = [...logs].reverse();

  reversed.forEach(log => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid var(--border-glass)';
    const dateStr = new Date(log.logged_at).toLocaleDateString();

    tr.innerHTML = `
      <td style="padding: 10px 8px;">${dateStr}</td>
      <td style="padding: 10px 8px; font-weight: bold; color: #fff;">${log.weight} kg</td>
      <td style="padding: 10px 8px;">${log.notes || '-'}</td>
      <td style="padding: 10px 8px; text-align: right;">
        <button onclick="deleteLogEntry(${log.id})" style="background: none; border: none; color: var(--accent-rose); cursor: pointer;">
          <i class="fa-solid fa-trash"></i>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

async function deleteLogEntry(logId) {
  if (!confirm('Delete this weight entry?')) return;
  try {
    const res = await window.apiFetch(`/api/tracker/weight-logs/${logId}`, { method: 'DELETE' });
    if (res.ok) {
      fetchWeightLogs();
      if (window.loadGlobalProfile) window.loadGlobalProfile();
    }
  } catch (err) {
    console.error('Error deleting log entry:', err);
  }
}

window.updateWeightChart = fetchWeightLogs;
window.deleteLogEntry = deleteLogEntry;
