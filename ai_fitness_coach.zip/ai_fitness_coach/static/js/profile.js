// Profile & BMI Management
document.addEventListener('DOMContentLoaded', () => {
  const profileForm = document.getElementById('userProfileForm');

  if (profileForm) {
    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const payload = {
        name: document.getElementById('profName').value,
        age: parseInt(document.getElementById('profAge').value),
        gender: document.getElementById('profGender').value,
        height: parseFloat(document.getElementById('profHeight').value),
        weight: parseFloat(document.getElementById('profWeight').value),
        target_weight: parseFloat(document.getElementById('profWeight').value) - 5,
        fitness_goal: document.getElementById('profGoal').value,
        fitness_level: document.getElementById('profLevel').value
      };

      try {
        const res = await window.apiFetch('/api/profile/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (res.ok) {
          const updated = await res.json();
          window.updateGlobalProfileUI(updated);
          renderBmiDetails(updated.bmi, updated.bmi_category);
          
          // Trigger workout reload for new goal
          if (window.loadWorkoutPlan) {
            window.loadWorkoutPlan(updated.fitness_goal, updated.fitness_level);
          }
          
          alert('Profile & BMI updated successfully!');
        }
      } catch (err) {
        console.error('Failed to update profile:', err);
      }
    });
  }
  if (window.getAuthToken && window.getAuthToken()) {
    fetchProfileData();
  }
});

async function fetchProfileData() {
  try {
    const res = await window.apiFetch('/api/profile/');
    if (res.ok) {
      const data = await res.json();
      populateProfileForm(data);
      renderBmiDetails(data.bmi, data.bmi_category);
    }
  } catch (err) {
    console.error('Error loading profile:', err);
  }
}

function populateProfileForm(data) {
  if (!data) return;
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };

  setVal('profName', data.name);
  setVal('profAge', data.age);
  setVal('profGender', data.gender);
  setVal('profHeight', data.height);
  setVal('profWeight', data.weight);
  setVal('profGoal', data.fitness_goal);
  setVal('profLevel', data.fitness_level);

  renderBmiDetails(data.bmi, data.bmi_category);
}

function renderBmiDetails(bmi, category) {
  const valEl = document.getElementById('bmiDisplayVal');
  const catEl = document.getElementById('bmiDisplayCategory');
  const dotEl = document.getElementById('bmiIndicatorDot');
  const adviceEl = document.getElementById('bmiAdviceText');

  if (valEl) valEl.innerText = bmi;
  if (catEl) {
    catEl.innerText = category;
    if (category === 'Normal Weight') {
      catEl.className = 'badge-pill badge-emerald';
    } else if (category === 'Underweight') {
      catEl.className = 'badge-pill badge-blue';
    } else {
      catEl.className = 'badge-pill badge-amber';
    }
  }

  // Position indicator dot on scale (15 to 35 range)
  if (dotEl) {
    let pct = ((bmi - 15) / 20) * 100;
    pct = Math.max(5, Math.min(95, pct));
    dotEl.style.left = `${pct}%`;
  }

  if (adviceEl) {
    if (category === 'Normal Weight') {
      adviceEl.innerText = 'Great job! Your BMI is in the healthy optimal range. Focus on maintaining muscle mass and functional stamina.';
    } else if (category === 'Underweight') {
      adviceEl.innerText = 'Consider a moderate caloric surplus with progressive resistance strength training to gain lean muscle tissue safely.';
    } else {
      adviceEl.innerText = 'A structured caloric deficit combined with consistent weekly cardio & resistance training will bring your body composition to target.';
    }
  }
}

window.populateProfileForm = populateProfileForm;
window.fetchProfileData = fetchProfileData;
