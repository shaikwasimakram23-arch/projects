// AI Trainer Chat Handler & Quick Ask Widget
document.addEventListener('DOMContentLoaded', () => {
  const btnSend = document.getElementById('btnSendChat');
  const btnQuickAsk = document.getElementById('btnQuickAiAsk');
  
  if (btnSend) {
    btnSend.addEventListener('click', handleChatSubmit);
  }

  if (btnQuickAsk) {
    btnQuickAsk.addEventListener('click', handleQuickAskSubmit);
  }

  // Setup prompt chips
  const chips = document.querySelectorAll('.chip');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const query = chip.getAttribute('data-query');
      const input = document.getElementById('chatInputText');
      if (input) {
        input.value = query;
        handleChatSubmit();
      }
    });
  });
});

async function handleChatSubmit() {
  const input = document.getElementById('chatInputText');
  const chatWindow = document.getElementById('chatMessageWindow');
  
  if (!input || !chatWindow) return;
  const userText = input.value.trim();
  if (!userText) return;

  // Render User Message
  const userBubble = document.createElement('div');
  userBubble.className = 'message-bubble user-msg';
  userBubble.innerText = userText;
  chatWindow.appendChild(userBubble);

  input.value = '';
  chatWindow.scrollTop = chatWindow.scrollHeight;

  // Thinking indicator
  const thinkingBubble = document.createElement('div');
  thinkingBubble.className = 'message-bubble ai-msg';
  thinkingBubble.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> AI Trainer is formulating advice...';
  chatWindow.appendChild(thinkingBubble);
  chatWindow.scrollTop = chatWindow.scrollHeight;

  try {
    const res = await window.apiFetch('/api/chat/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userText })
    });

    if (res.ok) {
      const data = await res.json();
      chatWindow.removeChild(thinkingBubble);
      renderAiChatBubble(data, chatWindow);
    }
  } catch (err) {
    chatWindow.removeChild(thinkingBubble);
    console.error('AI chat error:', err);
  }
}

function renderAiChatBubble(data, container) {
  const aiBubble = document.createElement('div');
  aiBubble.className = 'message-bubble ai-msg';

  let html = `<div>${data.reply}</div>`;

  if (data.warnings && data.warnings.length > 0) {
    html += `
      <div class="ai-warning-box">
        <strong>⚠️ Warnings / Exercises to Avoid:</strong>
        <ul style="margin-left: 18px; margin-top: 4px;">
          ${data.warnings.map(w => `<li>${w}</li>`).join('')}
        </ul>
      </div>
    `;
  }

  if (data.recommendations && data.recommendations.length > 0) {
    html += `
      <div class="ai-rec-box">
        <strong>Recommended Activities:</strong>
        <ul style="margin-left: 18px; margin-top: 4px; list-style-type: none;">
          ${data.recommendations.map(r => `<li>✓ ${r}</li>`).join('')}
        </ul>
      </div>
    `;
  }

  aiBubble.innerHTML = html;
  container.appendChild(aiBubble);
  container.scrollTop = container.scrollHeight;
}

// Quick AI Ask Handler on Dashboard
async function handleQuickAskSubmit() {
  const input = document.getElementById('quickAiInput');
  const resultDiv = document.getElementById('quickAiResult');
  const replyEl = document.getElementById('quickAiReplyText');
  const warnEl = document.getElementById('quickAiWarnList');
  const recEl = document.getElementById('quickAiRecList');

  if (!input || !resultDiv) return;
  const userText = input.value.trim();
  if (!userText) return;

  resultDiv.style.display = 'block';
  replyEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Consulting AI Fitness Coach...';
  warnEl.style.display = 'none';
  recEl.style.display = 'none';

  try {
    const res = await window.apiFetch('/api/chat/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userText })
    });

    if (res.ok) {
      const data = await res.json();
      replyEl.innerText = data.reply;

      if (data.warnings && data.warnings.length > 0) {
        warnEl.style.display = 'block';
        warnEl.innerHTML = `<strong>⚠️ Warning:</strong><br>${data.warnings.join('<br>')}`;
      }

      if (data.recommendations && data.recommendations.length > 0) {
        recEl.style.display = 'block';
        recEl.innerHTML = `<strong>Recommended:</strong><br>${data.recommendations.map(r => `✓ ${r}`).join('<br>')}`;
      }
    }
  } catch (err) {
    replyEl.innerText = 'Failed to fetch AI response.';
  }
}
