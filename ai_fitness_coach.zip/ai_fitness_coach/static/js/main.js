// Auth State & API Wrapper
function getAuthToken() {
  return localStorage.getItem('access_token');
}

function setAuthToken(token) {
  localStorage.setItem('access_token', token);
}

function logout() {
  localStorage.removeItem('access_token');
  showAuthUI();
}

async function apiFetch(url, options = {}) {
  const token = getAuthToken();
  const headers = {
    ...options.headers
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  // Only set Content-Type if not using FormData (browser sets it automatically for FormData)
  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  
  const response = await fetch(url, { ...options, headers });
  
  if (response.status === 401) {
    logout();
    throw new Error("Unauthorized");
  }
  
  return response;
}

// UI State Management
function checkAuthState() {
  if (getAuthToken()) {
    showAppUI();
    loadGlobalProfile();
    if (window.updateWeightChart) window.updateWeightChart();
    if (window.loadWorkoutPlan) window.loadWorkoutPlan();
    if (window.fetchProfileData) window.fetchProfileData();
  } else {
    showAuthUI();
  }
}

function showAuthUI() {
  document.getElementById('authContainer').style.display = 'flex';
  document.getElementById('appContainer').style.display = 'none';
}

function showAppUI() {
  document.getElementById('authContainer').style.display = 'none';
  document.getElementById('appContainer').style.display = 'block';
}

// Auth Forms Logic
function initAuthLogic() {
  const tabLogin = document.getElementById('tabLogin');
  const tabRegister = document.getElementById('tabRegister');
  const loginFormContainer = document.getElementById('loginFormContainer');
  const registerFormContainer = document.getElementById('registerFormContainer');

  tabLogin.addEventListener('click', () => {
    tabLogin.classList.add('active');
    tabRegister.classList.remove('active');
    loginFormContainer.style.display = 'block';
    registerFormContainer.style.display = 'none';
  });

  tabRegister.addEventListener('click', () => {
    tabRegister.classList.add('active');
    tabLogin.classList.remove('active');
    registerFormContainer.style.display = 'block';
    loginFormContainer.style.display = 'none';
  });

  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('username', document.getElementById('loginUsername').value);
    formData.append('password', document.getElementById('loginPassword').value);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        body: formData // OAuth2PasswordRequestForm expects form data
      });
      const data = await res.json();
      if (res.ok) {
        setAuthToken(data.token);
        document.getElementById('loginError').style.display = 'none';
        checkAuthState();
      } else {
        const errorEl = document.getElementById('loginError');
        errorEl.innerText = data.detail || 'Login failed';
        errorEl.style.display = 'block';
      }
    } catch (err) {
      const errorEl = document.getElementById('loginError');
      errorEl.innerText = 'Network error';
      errorEl.style.display = 'block';
    }
  });

  document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      username: document.getElementById('regUsername').value,
      email: document.getElementById('regEmail').value,
      password: document.getElementById('regPassword').value,
      name: "Fitness Enthusiast"
    };

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        setAuthToken(data.token);
        document.getElementById('regError').style.display = 'none';
        checkAuthState();
      } else {
        const errorEl = document.getElementById('regError');
        errorEl.innerText = data.detail || 'Registration failed';
        errorEl.style.display = 'block';
      }
    } catch (err) {
      const errorEl = document.getElementById('regError');
      errorEl.innerText = 'Network error';
      errorEl.style.display = 'block';
    }
  });

  document.getElementById('btnLogout').addEventListener('click', logout);
}


// Main Controller - Tab Navigation & Global State
document.addEventListener('DOMContentLoaded', () => {
  initAuthLogic();
  initTabs();
  initWaterTracker();
  checkAuthState();
});

function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetTab = button.getAttribute('data-tab');

      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));

      button.classList.add('active');
      document.getElementById(targetTab).classList.add('active');

      // Trigger re-render of chart if entering tracker tab
      if (targetTab === 'tab-tracker' && window.updateWeightChart) {
        window.updateWeightChart();
      }
    });
  });
}

// Interactive Water Tracker
let currentWaterL = 2.0;

function initWaterTracker() {
  const btnAdd = document.getElementById('btnWaterAdd');
  const btnSub = document.getElementById('btnWaterSub');

  if (btnAdd && btnSub) {
    btnAdd.addEventListener('click', () => {
      if (currentWaterL < 5.0) {
        currentWaterL = Math.round((currentWaterL + 0.25) * 100) / 100;
        updateWaterUI();
      }
    });

    btnSub.addEventListener('click', () => {
      if (currentWaterL > 0.0) {
        currentWaterL = Math.round((currentWaterL - 0.25) * 100) / 100;
        updateWaterUI();
      }
    });
  }
}

function updateWaterUI() {
  const waterCount = document.getElementById('dashWaterCount');
  const dashWater = document.getElementById('dashWater');
  if (waterCount) waterCount.innerText = `${currentWaterL}L`;
  if (dashWater) dashWater.innerText = `${currentWaterL} / 3.0 L`;
}

// Global Profile Quick Sync
async function loadGlobalProfile() {
  try {
    const res = await apiFetch('/api/profile/');
    if (res.ok) {
      const data = await res.json();
      updateGlobalProfileUI(data);
    }
  } catch (err) {
    console.error('Error fetching profile:', err);
  }
}

function updateGlobalProfileUI(data) {
  document.getElementById('navUserName').innerText = data.name;
  document.getElementById('navBmiBadge').innerText = `BMI: ${data.bmi} (${data.bmi_category})`;
  document.getElementById('navGoalBadge').innerText = data.fitness_goal;

  document.getElementById('dashWeight').innerText = `${data.weight} kg`;
  document.getElementById('dashBmi').innerText = data.bmi;
  document.getElementById('dashGoal').innerText = data.fitness_goal;

  // Also update profile form if rendered
  if (window.populateProfileForm) {
    window.populateProfileForm(data);
  }
}

// Export for other scripts
window.apiFetch = apiFetch;
window.loadGlobalProfile = loadGlobalProfile;
window.updateGlobalProfileUI = updateGlobalProfileUI;
window.getAuthToken = getAuthToken;
