// Workout Routine Generator & Renderer
document.addEventListener('DOMContentLoaded', () => {
  const btnRegenerate = document.getElementById('btnGenerateWorkout');
  if (btnRegenerate) {
    btnRegenerate.addEventListener('click', () => loadWorkoutPlan());
  }
  if (window.getAuthToken && window.getAuthToken()) {
    loadWorkoutPlan();
  }
});

async function loadWorkoutPlan(goalOverride = null, levelOverride = null) {
  const container = document.getElementById('workoutGridContainer');
  if (!container) return;

  container.innerHTML = '<div style="color: var(--text-muted); text-align: center; grid-column: span 3; padding: 40px;">Generating personalized workout schedule...</div>';

  try {
    let url = '/api/workout/generate';
    if (goalOverride && levelOverride) {
      url += `?fitness_goal=${encodeURIComponent(goalOverride)}&fitness_level=${encodeURIComponent(levelOverride)}`;
    }

    const res = await window.apiFetch(url);
    if (res.ok) {
      const data = await res.json();
      renderWorkoutSchedule(data.weekly_schedule);
    }
  } catch (err) {
    console.error('Error generating workout plan:', err);
    container.innerHTML = '<div style="color: var(--accent-rose); text-align: center; grid-column: span 3;">Failed to generate workout plan. Please try again.</div>';
  }
}

function renderWorkoutSchedule(schedule) {
  const container = document.getElementById('workoutGridContainer');
  container.innerHTML = '';

  schedule.forEach(dayPlan => {
    const card = document.createElement('div');
    card.className = `glass-card day-card ${dayPlan.is_rest_day ? 'rest-day' : ''}`;

    let exercisesHTML = '';
    if (dayPlan.is_rest_day) {
      exercisesHTML = `
        <div style="padding: 20px 0; text-align: center; color: var(--text-muted);">
          <i class="fa-solid fa-mug-hot" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i>
          <strong>Rest & Recovery Day</strong>
          <p style="font-size: 0.8rem; margin-top: 4px;">Light walking or stretching only.</p>
        </div>
      `;
    } else {
      dayPlan.exercises.forEach(ex => {
        const badgeText = ex.duration ? ex.duration : `${ex.sets} × ${ex.reps}`;
        exercisesHTML += `
          <div class="exercise-item">
            <div class="ex-details">
              <span class="ex-name">${ex.name}</span>
              <span class="ex-target"><i class="fa-solid fa-bullseye"></i> ${ex.muscle_group}</span>
            </div>
            <span class="ex-badge">${badgeText}</span>
          </div>
        `;
      });
    }

    card.innerHTML = `
      <div class="day-header">
        <h3 style="font-size: 1.1rem; color: #fff;">${dayPlan.day}</h3>
        <span class="badge-pill ${dayPlan.is_rest_day ? 'badge-amber' : 'badge-blue'}">
          ${dayPlan.is_rest_day ? 'Rest' : 'Workout'}
        </span>
      </div>
      <div style="font-size: 0.9rem; color: var(--text-sub); margin-bottom: 14px; font-weight: 600;">
        ${dayPlan.title}
      </div>
      <div class="exercise-list">
        ${exercisesHTML}
      </div>
    `;

    container.appendChild(card);
  });
}

window.loadWorkoutPlan = loadWorkoutPlan;
