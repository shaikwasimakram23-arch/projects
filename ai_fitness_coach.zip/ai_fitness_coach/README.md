# AI Personal Fitness Coach

Welcome to the **AI Personal Fitness Coach** project! This is a comprehensive, full-stack web application designed to help users track their fitness journey, generate workouts, log weight, and consult with an AI coach.

## 🚀 Features & Architecture

### Frontend (Client-Side)
- **UI/UX**: Beautiful, modern Glassmorphism design with a dark mode aesthetic, smooth CSS animations, glowing gradients, and responsive layouts.
- **Tech Stack**: Vanilla HTML5, CSS3, and JavaScript (ES6+).
- **Core Modules** (`static/js/`):
  - `main.js`: Handles JWT Authentication (Login/Register logic), API fetch wrappers with token injection, and global tab navigation.
  - `profile.js`: Manages user profile data (height, weight, goals, BMI calculation).
  - `workout.js`: Dynamically generates personalized workout routines based on the user's fitness goals and level.
  - `tracker.js`: Logs weight entries and visualizes progress using an interactive `Chart.js` graph.
  - `calories.js`: Calculates calories burned based on specific activities, duration, and user weight.
  - `chat.js`: Interfaces with the AI backend to provide conversational fitness advice.

### Backend (Server-Side)
- **Framework**: FastAPI (High-performance, async Python web framework).
- **Database**: SQLite (`fitness_coach.db`) with SQLAlchemy ORM.
- **Authentication**: JWT (JSON Web Tokens) with standard `bcrypt` password hashing to secure endpoints.
- **Core Modules** (`app/`):
  - `main.py`: Entry point for FastAPI, mounts static files, and includes API routers.
  - `models.py`: SQLAlchemy database schemas (User Profiles, Weight Logs, Activities, Workout Routines, Chat History).
  - `schemas.py`: Pydantic models for request/response validation.
  - `auth.py`: JWT token generation and password verification utilities.
  - `routes/`: Modular endpoints (`auth_routes`, `profile_routes`, `workout_routes`, `tracker_routes`, `calories_routes`, `chat_routes`).

---

## 🛠️ Setup & Installation

1. **Ensure you have Python installed** (Python 3.8+ recommended).
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
   *(Note: The requirements include `fastapi`, `uvicorn`, `sqlalchemy`, `pydantic`, `bcrypt`, and `python-jose`)*

---

## 🏃 Commands to Run the Project

To start the local development server, simply run the provided `run.py` script:

```bash
python run.py
```

### Accessing the App:
Once the server is running, open your web browser and navigate to:
- **Web Interface**: [http://127.0.0.1:8000](http://127.0.0.1:8000)
- **Interactive API Documentation (Swagger UI)**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **Alternative API Docs (ReDoc)**: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

### Testing the Authentication:
When you first open the web interface, you will be greeted by the secure login screen. 
1. Click **Register** to create a new account (all passwords are securely hashed).
2. Once registered, log in to access your personal dashboard.
3. Your session is maintained via JWT tokens stored in your browser's local storage.
