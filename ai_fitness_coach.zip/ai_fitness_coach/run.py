import uvicorn
import sys
import os

if __name__ == "__main__":
    print("=" * 65)
    print("      STARTING AI PERSONAL FITNESS COACH APPLICATION")
    print("=" * 65)
    print("  [>] Web App Server: http://127.0.0.1:8000")
    print("  [>] Interactive API Docs: http://127.0.0.1:8000/docs")
    print("=" * 65)
    
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
