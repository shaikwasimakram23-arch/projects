import os
import json

def get_file_contents():
    files_to_process = [
        '.\\README.md', '.\\requirements.txt', '.\\run.py', '.\\app\\ai_coach.py', '.\\app\\auth.py', 
        '.\\app\\calories_engine.py', '.\\app\\database.py', '.\\app\\main.py', '.\\app\\models.py', 
        '.\\app\\schemas.py', '.\\app\\workout_engine.py', '.\\app\\__init__.py', 
        '.\\app\\routes\\auth_routes.py', '.\\app\\routes\\calorie_routes.py', 
        '.\\app\\routes\\chat_routes.py', '.\\app\\routes\\profile_routes.py', 
        '.\\app\\routes\\tracker_routes.py', '.\\app\\routes\\workout_routes.py', 
        '.\\app\\routes\\__init__.py', '.\\static\\index.html', '.\\static\\css\\styles.css', 
        '.\\static\\js\\calories.js', '.\\static\\js\\chat.js', '.\\static\\js\\main.js', 
        '.\\static\\js\\profile.js', '.\\static\\js\\tracker.js', '.\\static\\js\\workout.js'
    ]
    
    cells = []
    
    # Title cell
    cells.append({
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "# AI Fitness Coach\n",
            "This notebook contains the full AI Fitness Coach application. Run all cells to start the web app in Colab."
        ]
    })
    
    # Setup cell
    cells.append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "import os\n",
            "\n",
            "os.makedirs('app/routes', exist_ok=True)\n",
            "os.makedirs('static/css', exist_ok=True)\n",
            "os.makedirs('static/js', exist_ok=True)\n"
        ]
    })

    # Add each file as a %%writefile cell
    for filepath in files_to_process:
        if not os.path.exists(filepath):
            continue
            
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Clean up filepath for colab
        unix_path = filepath.replace('.\\', '').replace('\\', '/')
        
        cell_source = [f"%%writefile {unix_path}\n"]
        cell_source.extend([line + "\n" if not line.endswith("\n") else line for line in content.splitlines()])
        
        cells.append({
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": cell_source
        })
        
    # Final cell to run the app
    run_app_source = [
        "!pip install -r requirements.txt\n",
        "!pip install pyngrok nest-asyncio\n",
        "\n",
        "import nest_asyncio\n",
        "from pyngrok import ngrok\n",
        "import uvicorn\n",
        "import os\n",
        "\n",
        "# You can get an authtoken from https://dashboard.ngrok.com/get-started/your-authtoken\n",
        "# ngrok.set_auth_token('YOUR_NGROK_AUTH_TOKEN')\n",
        "\n",
        "try:\n",
        "    ngrok_tunnel = ngrok.connect(8000)\n",
        "    print('Public URL:', ngrok_tunnel.public_url)\n",
        "    nest_asyncio.apply()\n",
        "    uvicorn.run(\"app.main:app\", port=8000)\n",
        "except Exception as e:\n",
        "    print(\"Error starting ngrok. You may need to create a free account and set your auth token.\", e)\n"
    ]
    
    cells.append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": run_app_source
    })
    
    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "codemirror_mode": {
                    "name": "ipython",
                    "version": 3
                },
                "file_extension": ".py",
                "mimetype": "text/x-python",
                "name": "python",
                "nbconvert_exporter": "python",
                "pygments_lexer": "ipython3",
                "version": "3.8.0"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 4
    }
    
    with open('ai_fitness_coach_colab.ipynb', 'w', encoding='utf-8') as f:
        json.dump(notebook, f, indent=2)

if __name__ == '__main__':
    get_file_contents()
    print("Notebook generated successfully!")
