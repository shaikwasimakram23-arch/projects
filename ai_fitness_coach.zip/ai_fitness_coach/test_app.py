import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi.testclient import TestClient
from app.main import app

def run_tests():
    print("[TEST] Testing AI Personal Fitness Coach FastAPI Backend...")
    client = TestClient(app)

    # 1. Profile test
    res = client.get("/api/profile/")
    assert res.status_code == 200
    profile = res.json()
    print(f"  OK Profile Loaded: {profile['name']} | Weight: {profile['weight']}kg | BMI: {profile['bmi']} ({profile['bmi_category']})")

    # 2. Workout plan test
    res = client.get("/api/workout/generate")
    assert res.status_code == 200
    workout = res.json()
    print(f"  OK Workout Routine Generated: {len(workout['weekly_schedule'])} Days created for Goal: {workout['fitness_goal']}")

    # 3. AI Chat test (Knee pain query)
    res = client.post("/api/chat/", json={"message": "I have knee pain. What workout should I do?"})
    assert res.status_code == 200
    chat = res.json()
    print(f"  OK AI Chat Response: {chat['reply'][:60]}...")
    print(f"  OK Warnings: {chat['warnings']}")
    print(f"  OK Recommended: {chat['recommendations']}")

    # 4. Calorie calculation test (Running 30 mins)
    res = client.post("/api/calories/calculate", json={"activity": "Running (8 km/h)", "duration_minutes": 30})
    assert res.status_code == 200
    cal = res.json()
    print(f"  OK Calorie Burn Test: Running 30 mins = {cal['calories_burned']} kcal (MET: {cal['met_value']})")

    # 5. Weight logs test
    res = client.get("/api/tracker/weight-logs")
    assert res.status_code == 200
    logs = res.json()
    print(f"  OK Weight Logs Fetched: {len(logs)} logs in history.")

    print("\n[SUCCESS] ALL BACKEND & ENGINE VERIFICATION TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    run_tests()
